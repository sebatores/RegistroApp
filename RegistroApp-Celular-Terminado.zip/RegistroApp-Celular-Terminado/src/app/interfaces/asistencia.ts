export interface Asistencia {
  bloqueInicio: number;
  bloqueTermino: number;
  dia: string;
  horaFin: string;
  horaInicio: string;
  idAsignatura: string;
  nombreAsignatura: string;
  nombreProfesor: string;
  seccion: string;
  sede: string;
}
