import { DataBaseService } from './../../services/data-base.service';
import { HeaderComponent } from './../../components/header/header.component';
import { AuthService } from 'src/app/services/auth.service';
import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule, AlertController } from '@ionic/angular'; // Importa el IonicModule para asegurarte de que los componentes de Ionic sean reconocidos
import { NavigationExtras, Router } from '@angular/router';
import { showToast } from 'src/app/tools/message-functions'; // Función para mostrar mensajes Toast
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core'; // Importa CUSTOM_ELEMENTS_SCHEMA
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-correo',
  templateUrl: './correo.page.html',
  styleUrls: ['./correo.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonicModule, // Importa IonicModule para habilitar los componentes de Ionic
    HeaderComponent,
    TranslateModule 
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA] // Agrega CUSTOM_ELEMENTS_SCHEMA para los web components de Ionic
})
export class CorreoPage  {

  public correo: string = ''; // Para almacenar el correo ingresado

  constructor(
    private dataBaseService:DataBaseService,
    private router: Router,
    private alertController: AlertController // Inyectar AlertController para mostrar alertas
  ) { }

  // Método para enviar a la pregunta
  async enviarCorreoRecuperacion() { 
    try {
      this.dataBaseService.buscarUsuarioPorCorreo(this.correo).then((usuario) => {
        if (usuario) {
          const navigationExtra: NavigationExtras = {
            state: { usuario: usuario } // Envía los datos del usuario
          };
          this.router.navigate(['/pregunta'], navigationExtra); // Redirige a la página si el usuario existe
        } else {
          this.router.navigate(['/incorrecto']);
        }
      });
    } catch (error) {
      // Muestra una alerta en caso de error
      this.mostrarAlerta('Error', 'Ocurrió un error al enviar el correo.');
      console.error(error);
    }
  }
  showToast(arg0: string) {
    throw new Error('Method not implemented.');
  }
  mostrarMensajeEmergenteCorreoVacio() {
    throw new Error('Method not implemented.');
  }
  
  // Método para mostrar una alerta
  async mostrarAlerta(titulo: string, mensaje: string) {
    const alert = await this.alertController.create({
      header: titulo,
      message: mensaje,
      buttons: ['OK']
    });
    await alert.present();
  }
  redirigirAlLogin(): void {
    this.router.navigate(['/ingreso']); 
  }
}
