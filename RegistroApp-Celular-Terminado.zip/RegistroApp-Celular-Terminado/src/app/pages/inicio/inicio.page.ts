import { Component, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonContent, IonToolbar, IonLabel, IonIcon, IonSegment, IonSegmentButton, IonFooter, IonHeader, IonTitle, IonButton } from '@ionic/angular/standalone';
import { CodigoqrComponent } from "../../components/codigoqr/codigoqr.component";
import { MisdatosComponent } from "../../components/misdatos/misdatos.component";
import { MiclaseComponent } from 'src/app/components/miclase/miclase.component';
import { ForoComponent } from 'src/app/components/foro/foro.component';
import { AuthService } from 'src/app/services/auth.service';
import { FooterComponent } from "../../components/footer/footer.component";
import { HeaderComponent } from "../../components/header/header.component";


@Component({
    selector: 'app-inicio',
    templateUrl: './inicio.page.html',
    styleUrls: ['./inicio.page.scss'],
    standalone: true,
    imports: [IonButton, IonHeader,
        IonLabel, IonFooter, IonSegmentButton, IonSegment,
        IonIcon, IonToolbar, IonTitle, CommonModule, FormsModule, IonContent,
        CodigoqrComponent, MiclaseComponent, ForoComponent, MisdatosComponent, FooterComponent, HeaderComponent]
})
export class InicioPage {

    @ViewChild(FooterComponent) footer!: FooterComponent;
    selectedComponent: string = 'codigoqr';

    constructor(private authService: AuthService)
    {
        this.authService.selectedComponent.subscribe((selectedComponent) => {
            this.selectedComponent = selectedComponent;
        });
    }

    ionViewWillEnter() {
        this.changeComponent('codigoqr')
    }

    logout() {
        this.authService.logout(); 
    }

    footerClick(button: string) {
        this.selectedComponent = button;
    }

    changeComponent(name: string) {
        this.selectedComponent = name;
        this.footer.selectedButton = name;
    }
 
}

