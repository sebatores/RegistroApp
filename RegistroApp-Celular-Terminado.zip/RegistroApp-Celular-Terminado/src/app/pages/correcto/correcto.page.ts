import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonGrid, IonCardContent, IonCardHeader, IonCard, IonContent, IonButton, IonCol, IonRow, IonCardTitle, IonLabel, IonItem } from "@ionic/angular/standalone";
import { Router } from '@angular/router';
import { HeaderComponent } from 'src/app/components/header/header.component';
import { DataBaseService } from 'src/app/services/data-base.service';
import { Usuario } from 'src/app/model/usuario';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-correcto',
  templateUrl: './correcto.page.html',
  styleUrls: ['./correcto.page.scss'],
  standalone: true,
  imports: [IonItem, IonLabel, IonCardTitle, IonRow, IonCol, IonButton, IonContent, IonCard, IonCardHeader, IonCardContent, IonGrid, CommonModule, FormsModule, HeaderComponent, TranslateModule]
})
export class CorrectoPage implements OnInit {
  public password: string | null = null; // Almacena la contraseña recibida

  @ViewChild('titulo', { read: ElementRef }) titulo!: ElementRef;

  constructor(
    private router: Router,
    private dataBaseService: DataBaseService,
  ) { }

  ngOnInit(): void {
    const navigation = this.router.getCurrentNavigation();
    if (navigation?.extras?.state) {
      this.password = navigation.extras.state['password'] || null; // Obtener la contraseña del estado de navegación
      if (this.password) {
        console.log('Contraseña recibida en CorrectoPage:', this.password);
      } else {
        console.error('No se pudo encontrar la contraseña en el estado de navegación.');
      }
    } else {
      console.error('No se pudo acceder al estado de navegación.');
    }
  }

  redirigirAlLogin(): void {
    this.router.navigate(['/ingreso']); 
  }
}
