import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonContent, IonHeader, IonTitle, IonToolbar, IonCard, IonCardTitle, IonCardContent, IonGrid, IonRow, IonCol, IonButton, IonCardHeader, IonItem, IonLabel } from '@ionic/angular/standalone';
import { Router } from '@angular/router';
import { HeaderComponent } from 'src/app/components/header/header.component';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-incorrecto',
  templateUrl: './incorrecto.page.html',
  styleUrls: ['./incorrecto.page.scss'],
  standalone: true,
  imports: [IonLabel, IonItem, IonCardHeader, IonButton, IonCol, IonRow, IonGrid, IonCardContent, IonCardTitle, IonCard, IonContent, IonHeader, IonTitle, IonToolbar, CommonModule, FormsModule, HeaderComponent, TranslateModule]
})
export class IncorrectoPage implements OnInit {

  constructor(
    private router: Router,
  ) { }

  ngOnInit() {
  }

  redirigirAlLogin(): void {
    this.router.navigate(['/ingreso']); 
  }
}
