import { AuthService } from 'src/app/services/auth.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonContent, IonHeader, IonTitle, IonToolbar, IonCard, IonCardContent, IonCardHeader, IonItem, IonButton, IonInput, IonIcon, IonCardTitle, IonCardSubtitle, IonLabel } from '@ionic/angular/standalone';
import { HeaderComponent } from "../../components/header/header.component";
import { FooterComponent } from "../../components/footer/footer.component";
import { Router } from '@angular/router';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { LanguageComponent } from 'src/app/components/language/language.component';
import { ViewWillEnter } from '@ionic/angular';
import { colorWandOutline } from 'ionicons/icons';
import { addIcons } from 'ionicons';

@Component({
    selector: 'app-ingreso',
    templateUrl: './ingreso.page.html',
    styleUrls: ['./ingreso.page.scss'],
    standalone: true,
    imports: [IonLabel, 
      IonCardSubtitle, IonCardTitle, IonIcon, IonInput,
      IonButton, IonItem, IonCardHeader, IonCardContent, 
      IonCard, IonContent, IonHeader, IonTitle, IonToolbar, 
      CommonModule, FormsModule, HeaderComponent, FooterComponent, 
      TranslateModule, LanguageComponent]
})
export class IngresoPage implements ViewWillEnter {

  @ViewChild('selectLanguage') selectLanguage!: LanguageComponent;

  public cuenta = '';
  public password = '';

  constructor(
    private authService: AuthService,
    private router: Router
  ) {
    this.cuenta = 'atorres';
    this.password = '1234';
    addIcons({ colorWandOutline });
  }

  async ionViewWillEnter() {
    this.selectLanguage.setCurrentLanguage();
  }
    
  ingresar(){
    this.authService.login(this.cuenta, this.password);
  }

  recuperar(){
    this.router.navigate(['/correo']);
  }

  rutaDuoc() {
    this.router.navigate(['/miruta']);
  }

  navigateTheme() {
    this.router.navigate(['/theme']);
  }

}