import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { HeaderComponent } from './../../components/header/header.component';
import { Usuario } from 'src/app/model/usuario';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-pregunta',
  templateUrl: './pregunta.page.html',
  styleUrls: ['./pregunta.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,  
    HeaderComponent,
    TranslateModule
  ]
})
export class PreguntaPage implements OnInit {
  public usuario: Usuario | undefined;  // usuario puede ser undefined al principio
  public respuesta: string = '';

  constructor(
    private router: Router,
    private activateRoute: ActivatedRoute
  ) { 
    this.activateRoute.queryParams.subscribe(() => {
      const navigation = this.router.getCurrentNavigation();
      if (navigation && navigation.extras.state) {
        this.usuario = navigation.extras.state['usuario'];
      } else {
        // Redirigir si no hay usuario en el estado de navegación
        this.router.navigate(['/ingreso']);
      }
    });
  }

  ngOnInit() {}

  public async validarRespuestaSecreta(): Promise<void> {
    if (!this.usuario) {
      // Si el usuario es undefined, redirigir a la página de ingreso
      await this.router.navigate(['/ingreso']);
      return;
    }

    if (this.usuario.respuestaSecreta === this.respuesta.trim()) {
      // Respuesta correcta, redirigir a /correcto con el usuario en el estado
      await this.router.navigate(['/correcto'], { state: { password: this.usuario.password } }); 
    } else {
      // Respuesta incorrecta, redirigir a /incorrecto
      await this.router.navigate(['/incorrecto']);
    }
  }
}
