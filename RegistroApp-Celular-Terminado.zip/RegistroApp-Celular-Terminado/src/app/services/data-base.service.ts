import { SQLiteDBConnection } from '@capacitor-community/sqlite';
import { Injectable } from '@angular/core';
import { SQLiteService } from './sqlite.service';
import { Usuario } from '../model/usuario';
import { BehaviorSubject } from 'rxjs';
import { NivelEducacional } from '../model/nivel-educacional';

@Injectable({
  providedIn: 'root'
})
export class DataBaseService {
  userUpgrades = [
    {
      toVersion: 1,
      statements: [`CREATE TABLE IF NOT EXISTS USUARIO (
          cuenta TEXT PRIMARY KEY NOT NULL,
          correo TEXT NOT NULL,
          password TEXT NOT NULL,
          preguntaSecreta TEXT NOT NULL,
          respuestaSecreta TEXT NOT NULL,
          nombre TEXT NOT NULL,
          apellido TEXT NOT NULL,
          nivelEducacional TEXT NOT NULL,
          fechaNacimiento INTEGER NOT NULL,
          direccion TEXT NOT NULL
        );`]
    }
  ];

  sqlInsertUpdate = `INSERT OR REPLACE INTO USUARIO (
      cuenta, 
      correo, 
      password, 
      preguntaSecreta, 
      respuestaSecreta,
      nombre, 
      apellido, 
      nivelEducacional, 
      fechaNacimiento, 
      direccion
    ) VALUES (?,?,?,?,?,?,?,?,?,?);
  `;

  nombreBD = 'basedatos';
  db!: SQLiteDBConnection;
  listaUsuarios: BehaviorSubject<Usuario[]> = new BehaviorSubject<Usuario[]>([]);
  datosQR: BehaviorSubject<string> = new BehaviorSubject('');

  constructor(private sqliteService: SQLiteService) {}

  async inicializarBaseDeDatos() {
    try {
      await this.sqliteService.crearBaseDeDatos({ database: this.nombreBD, upgrade: this.userUpgrades });
      this.db = await this.sqliteService.abrirBaseDeDatos(this.nombreBD, true, 'no-encryption', 1, false);
      
      await this.agregarColumnaDireccionSiNoExiste();
      await this.crearUsuariosDePrueba();
      await this.leerUsuarios();
    } catch (error) {
      console.error('Error durante la inicialización de la base de datos:', error);
    }
  }

  async crearUsuariosDePrueba() {
    try {
      await this.guardarUsuario(Usuario.getNewUsuario(
        'atorres', 
        'atorres@duocuc.cl', 
        '1234', 
        '¿Cuál es tu animal favorito?', 
        'gato',
        'Ana', 
        'Torres', 
        NivelEducacional.buscarNivelEducacional(6)!,
        new Date(2000, 0, 5),
        'Avenida Einstein, 661'
      ));
      
      await this.guardarUsuario(Usuario.getNewUsuario(
        'jperez', 
        'jperez@duocuc.cl', 
        '5678', 
        '¿Cuál es tu postre favorito?',
        'panqueques',
        'Juan', 
        'Pérez',
        NivelEducacional.buscarNivelEducacional(5)!,
        new Date(2000, 1, 10),
        'Calle La Aurora, 1895'
      ));
      
      await this.guardarUsuario(Usuario.getNewUsuario(
        'cmujica', 
        'cmujica@duocuc.cl', 
        '0987', 
        '¿Cuál es tu vehículo favorito?',
        'moto',
        'Carla', 
        'Mujica', 
        NivelEducacional.buscarNivelEducacional(6)!,
        new Date(2000, 2, 20),
        'Calle Napoleón, 3565'
      ));
    } catch (error) {
      console.error('Error al crear usuarios de prueba:', error);
    }
  }

  async guardarUsuario(usuario: Usuario): Promise<void> {
    try {
      const fechaNacimiento = usuario.fechaNacimiento instanceof Date 
        ? usuario.fechaNacimiento.getTime() // Convertir a timestamp
        : usuario.fechaNacimiento; // Usar directamente si ya es un timestamp

      await this.db.run(this.sqlInsertUpdate, [
        usuario.cuenta, 
        usuario.correo, 
        usuario.password,
        usuario.preguntaSecreta, 
        usuario.respuestaSecreta, 
        usuario.nombre, 
        usuario.apellido,
        JSON.stringify(usuario.nivelEducacional), // Guardar el objeto completo como JSON
        fechaNacimiento,
        usuario.direccion
      ]);
      await this.leerUsuarios();
    } catch (error) {
      console.error('Error al guardar usuario:', error);
    }
  }

  async leerUsuarios(): Promise<void> {
    try {
      const usuarios: Usuario[] = (await this.db.query('SELECT * FROM USUARIO;')).values as Usuario[];
      const usuariosConNivelEducacional = usuarios.map(usuario => {
        // Asume que nivelEducacional ya es un objeto de tipo NivelEducacional
        const nivelEducacional: NivelEducacional | undefined = usuario.nivelEducacional || undefined;
  
        // Asegúrate de que la fecha de nacimiento sea válida antes de crear el objeto Date
        const fechaNacimiento = usuario.fechaNacimiento 
          ? new Date(usuario.fechaNacimiento) 
          : undefined; // Manejar el caso de undefined
  
        return {
          ...usuario,
          nivelEducacional: nivelEducacional, // Se asume que ya es un objeto
          fechaNacimiento: fechaNacimiento // Asegúrate de que sea del tipo correcto
        } as Usuario; // Forzar el tipo a Usuario
      });
      this.listaUsuarios.next(usuariosConNivelEducacional);
    } catch (error) {
      console.error('Error al leer usuarios:', error);
    }
  }
  

  async leerUsuario(cuenta: string): Promise<Usuario | undefined> {
    try {
      const usuarios: Usuario[] = (await this.db.query(
        'SELECT * FROM USUARIO WHERE cuenta=?;', 
        [cuenta])).values as Usuario[];
      return usuarios[0];
    } catch (error) {
      console.error('Error al leer usuario:', error);
      return undefined; // Devuelve undefined en caso de error
    }
  }

  async eliminarUsuarioUsandoCuenta(cuenta: string): Promise<void> {
    try {
      await this.db.run('DELETE FROM USUARIO WHERE cuenta=?', [cuenta]);
      await this.leerUsuarios();
    } catch (error) {
      console.error('Error al eliminar usuario:', error);
    }
  }

  async buscarUsuarioValido(cuenta: string, password: string): Promise<Usuario | undefined> {
    try {
      const usuarios: Usuario[] = (await this.db.query(
        'SELECT * FROM USUARIO WHERE cuenta=? AND password=?;',
        [cuenta, password])).values as Usuario[];
      return usuarios[0];
    } catch (error) {
      console.error('Error al buscar usuario válido:', error);
      return undefined;
    }
  }

  async buscarUsuarioPorCuenta(cuenta: string): Promise<Usuario | undefined> {
    try {
      const usuarios: Usuario[] = (await this.db.query(
        'SELECT * FROM USUARIO WHERE cuenta=?;', 
        [cuenta])).values as Usuario[];
      return usuarios[0];
    } catch (error) {
      console.error('Error al buscar usuario por cuenta:', error);
      return undefined;
    }
  }

  async buscarUsuarioPorCorreo(correo: string): Promise<Usuario | undefined> {
    try {
      const usuarios: Usuario[] = (await this.db.query(
        'SELECT * FROM USUARIO WHERE correo=?;', 
        [correo])).values as Usuario[];
      return usuarios[0];
    } catch (error) {
      console.error('Error al buscar usuario por correo:', error);
      return undefined;
    }
  }

  async actualizarUsuario(usuario: Usuario): Promise<void> {
    debugger
    try {
      console.log('Actualizando usuario en la base de datos:', usuario); // Para depuración
      const sqlUpdate = `
        UPDATE USUARIO SET 
          correo = ?, 
          password = ?, 
          preguntaSecreta = ?, 
          respuestaSecreta = ?, 
          nombre = ?, 
          apellido = ?, 
          nivelEducacional = ?, 
          fechaNacimiento = ?, 
          direccion = ? 
        WHERE cuenta = ?;
      `;

      const fechaNacimiento = usuario.fechaNacimiento instanceof Date 
        ? usuario.fechaNacimiento.getTime() // Convertir a timestamp
        : usuario.fechaNacimiento; // Usar directamente si ya es un timestamp

      await this.db.run(sqlUpdate, [
        usuario.correo,
        usuario.password,
        usuario.preguntaSecreta,
        usuario.respuestaSecreta,
        usuario.nombre,
        usuario.apellido,
        JSON.stringify(usuario.nivelEducacional), // Guardar el objeto completo como JSON
        fechaNacimiento,
        usuario.direccion,
        usuario.cuenta // Asegúrate de que estás usando la cuenta como referencia
      ]);

      await this.leerUsuarios(); // Para refrescar la lista de usuarios
    } catch (error) {
      console.error('Error al actualizar usuario:', error);
    }
  }

  async agregarColumnaDireccionSiNoExiste() {
    try {
      const resultado = await this.db.query("PRAGMA table_info(USUARIO);");
      const columnas = resultado.values as { name: string }[];

      // Verifica si la columna 'direccion' ya existe
      const existeColumnaDireccion = columnas.some(col => col.name === 'direccion');

      if (!existeColumnaDireccion) {
        await this.db.run('ALTER TABLE USUARIO ADD COLUMN direccion TEXT;');
      }
    } catch (error) {
      console.error('Error al agregar la columna direccion:', error);
    }
  }
}
