import { Usuario } from './../model/usuario';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { showToast } from 'src/app/tools/message-functions';
import { Storage } from '@ionic/storage-angular';
import { DataBaseService } from './data-base.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  getUsuario(): any {
    throw new Error('Method not implemented.');
  }

  keyUsuario = 'USUARIO_AUTENTICADO';
  usuarioAutenticado = new BehaviorSubject<Usuario | null>(null);
  selectedComponent = new BehaviorSubject<string>('codigoqr');
  primerInicioSesion = new BehaviorSubject<boolean>(false);
  qrCodeData = new BehaviorSubject<string | null>(null);

  constructor(private router: Router, private bd: DataBaseService, private storage: Storage) {}

  async inicializarAutenticacion() {
    await this.storage.create();
  }

  async isAuthenticated(): Promise<boolean> {
    return await this.leerUsuarioAutenticado().then(usuario => {
      return usuario !== null;
    });
  }

  async leerUsuarioAutenticado(): Promise<Usuario | null> {
    const usuario = await this.storage.get(this.keyUsuario) as Usuario;
    this.usuarioAutenticado.next(usuario);
    return usuario;
  }

  guardarUsuarioAutenticado(usuario: Usuario) {
    this.storage.set(this.keyUsuario, usuario);
    this.usuarioAutenticado.next(usuario);
  }

  eliminarUsuarioAutenticado() {
    this.storage.remove(this.keyUsuario);
    this.usuarioAutenticado.next(null); 
  }

  async login(cuenta: string, password: string) {
    await this.bd.buscarUsuarioValido(cuenta, password).then(async (usuario: Usuario | undefined) => {
      if (usuario) {
        showToast(`¡Bienvenido(a) ${usuario.nombre} ${usuario.apellido}!`);
        this.guardarUsuarioAutenticado(usuario);
        this.primerInicioSesion.next(true); // Es el primer inicio de sesión
        this.router.navigate(['/inicio']);
      } else {
        showToast(`El correo o la contraseña son incorrectos`);
        this.router.navigate(['/ingreso']);
      }
    });
  }

  async logout() {
    const usuario = await this.leerUsuarioAutenticado();
    if (usuario) {
      showToast(`¡Hasta pronto ${usuario.nombre} ${usuario.apellido}!`);
      this.eliminarUsuarioAutenticado();
    }
    this.router.navigate(['/ingreso']);
  }

  async enviarCorreoRecuperacion(correo: string): Promise<boolean> {
    try {
      const usuario = await this.bd.buscarUsuarioPorCorreo(correo); // Busca el usuario por correo
      if (usuario) {
        showToast(`El correo se ha enviado a ${correo}.`);
        this.router.navigate(['/respuesta-secreta']); // Redirige a la página de respuesta secreta
        return true; // Retorna true si el usuario existe
      } else {
        showToast(`El correo electrónico no está registrado.`);
        return false; // Retorna false si el usuario no existe
      }
    } catch (error) {
      showToast('Error al verificar el correo.'); // Mensaje de error para otros errores
      console.error(error);
      return false;
    }
  }
}
