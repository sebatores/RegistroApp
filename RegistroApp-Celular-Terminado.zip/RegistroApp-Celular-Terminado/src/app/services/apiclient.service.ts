import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, lastValueFrom, Observable } from 'rxjs';
import { retry } from 'rxjs/operators';
import { showAlertError } from '../tools/message-functions';
import { Publicacion } from '../model/publicacion';
import { Post } from '../model/post';

@Injectable({
  providedIn: 'root'
})
export class APIClientService {

  // El objeto httpOptions en Angular se usa para configurar opciones adicionales
  // para las solicitudes HTTP, como los headers. En el ejemplo:
  // Content-Type: application/json, indica que los datos se envían en formato JSON.
  // Access-Control-Allow-Origin: *, para usar CORS (Cross-Origin Resource Sharing)
  // que permite el acceso a la API desde cualquier origen.

  httpOptions = {
    headers: new HttpHeaders({
      'content-type': 'application/json',
      'access-control-allow-origin': '*'
    })
  };

  //apiUrl = 'http://localhost:3000';
  apiUrl = 'http://192.168.91.123:3000';
  postList: BehaviorSubject<Post[]> = new BehaviorSubject<Post[]>([]);

  constructor(private http: HttpClient) { }

  // Crear una publicación y actualizar postList; devuelve el registro recién creado
  async createPost(post: Post): Promise<Post | null> {
    try {
      const postWithoutId = {
        "title": post.title,
        "body": post.body,
        "author": post.author,
        "date": post.date,
        "authorImage": post.authorImage
      };

      const createdPost = await lastValueFrom(
        this.http.post<Post>(this.apiUrl + '/posts', 
          postWithoutId, this.httpOptions).pipe(retry(3))
      );
      await this.refreshPostList();
      return createdPost;
    } catch (error) {
      showAlertError('APIClientService.createPost', error);
      return null;
    }
  }

  // Actualizar una publicación; devuelve la publicación actualizada
  async updatePost(post: Post): Promise<Post | null> {
    try {
      const updatedPost = await lastValueFrom(
        this.http.put<Post>(this.apiUrl + '/posts/' + post.id, 
          post, this.httpOptions).pipe(retry(3))
      );
      await this.refreshPostList();
      return updatedPost;
    } catch (error) {
      showAlertError('APIClientService.updatePost', error);
      return null;
    }
  }

  // Eliminar una publicación; devuelve true si se eliminó exitosamente
  async deletePost(id: number): Promise<boolean> {
    try {
      await lastValueFrom(
        this.http.delete(this.apiUrl + '/posts/' + id, this.httpOptions).pipe(retry(3))
      );
      await this.refreshPostList();
      return true;
    } catch (error) {
      showAlertError('APIClientService.deletePost', error);
      return false;
    }
  }

  // Refrescar el listado de publicaciones y notificar a los suscriptores
  async refreshPostList(): Promise<void> {
    try {
      const posts = await this.fetchPosts();
      console.log(posts);
      this.postList.next(posts);
    } catch (error) {
      showAlertError('APIClientService.refreshPostList', error);
    }
  }

  // Obtener todas las publicaciones desde la API
  async fetchPosts(): Promise<Post[]> {
    try {
      const posts = await lastValueFrom(
        this.http.get<Post[]>(this.apiUrl + '/posts').pipe(retry(3)));
      return posts.reverse();
    } catch (error) {
      this.handleHttpError('APIClientService.fetchPosts', error);
      return [];
    }
  }

  // Manejo de errores HTTP con detección de códigos de estado
  private handleHttpError(methodName: string, error: any): void {
    if (error instanceof HttpErrorResponse) {
      const statusCode = error.status;
      if (statusCode === 400) {
        showAlertError(`${methodName} - Solicitud incorrecta (400)`, error.message);
      } else if (statusCode === 401) {
        showAlertError(`${methodName} - No autorizado (401)`, error.message);
      } else if (statusCode === 404) {
        showAlertError(`${methodName} - No encontrado (404)`, error.message, true);
      } else if (statusCode === 500) {
        showAlertError(`${methodName} - Error interno del servidor (500)`, error.message);
      } else {
        showAlertError(`${methodName} - Error inesperado (${statusCode})`, error.message);
      }
    } else {
      showAlertError(`${methodName} - Error desconocido`, error);
    }
  }

}

















// import { Injectable } from '@angular/core';
// import { HttpClient, HttpHeaders } from '@angular/common/http';
// import { BehaviorSubject, Observable } from 'rxjs';
// import { Publicacion } from '../model/publicacion';
// import { showToast } from '../tools/message-routines';

// @Injectable({
//   providedIn: 'root'
// })
// export class APIClientService {

//   httpOptions = {
//     headers: new HttpHeaders({
//       'content-type': 'application/json',
//       'access-control-allow-origin': '*'
//     })
//   };

//   listaPublicaciones: BehaviorSubject<Publicacion[]> = new BehaviorSubject<Publicacion[]>([]);
//   //apiUrl = 'http://localhost:3000'; // Url al usar en navegador Web
//   apiUrl = 'http://192.168.100.34:3000'; // Url al usar en mi celular en mi WIFI, tu puedes tener otra IP
  
//   constructor(private http: HttpClient) { }

//   async cargarPublicaciones() {
//     this.leerPublicaciones().subscribe({
//       next: (publicaciones) => {
//         this.listaPublicaciones.next(publicaciones as Publicacion[]);
//       },
//       error: (error: any) => {
//         showToast('El servicio API Rest de Publicaciones no está disponible');
//         this.listaPublicaciones.next([]);
//       }
//     });
//   }

//   crearPublicacion(publicacion: any): Observable<any> {
//     return this.http.post(this.apiUrl + '/publicaciones/', publicacion, this.httpOptions);
//   }

//   leerPublicaciones(): Observable<any> {
//     return this.http.get(this.apiUrl + '/publicaciones/');
//   }

//   leerPublicacion(idPublicacion: number): Observable<any> {
//     return this.http.get(this.apiUrl + '/publicaciones/' + idPublicacion);
//   }

//   actualizarPublicacion(publicacion: any): Observable<any> {
//     return this.http.put(this.apiUrl + '/publicaciones/' + publicacion.id, publicacion, this.httpOptions);
//   }

//   eliminarPublicacion(publicacionId: number): Observable<any> {
//     return this.http.delete(this.apiUrl + '/publicaciones/' + publicacionId, this.httpOptions);
//   }

// }
