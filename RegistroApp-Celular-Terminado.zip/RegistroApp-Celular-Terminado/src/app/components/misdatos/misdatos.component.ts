import { Component, ElementRef, ViewChild } from '@angular/core';
import { Usuario } from 'src/app/model/usuario';
import { AnimationController, ToastController } from '@ionic/angular';
import { IonCard, IonItem, IonContent, IonInput, IonLabel, IonList, IonSelect, IonSelectOption, IonCardHeader, IonCardContent, IonCardTitle, IonButton } from "@ionic/angular/standalone"; 
import { FormsModule } from '@angular/forms';
import { NivelEducacional } from 'src/app/model/nivel-educacional';
import { DataBaseService } from 'src/app/services/data-base.service';
import { AuthService } from 'src/app/services/auth.service';
import { NgFor } from '@angular/common';
import { TranslateModule } from '@ngx-translate/core'; 
import { DatePickerComponent } from '../date-picker/date-picker.component';

@Component({
  selector: 'app-misdatos',
  templateUrl: './misdatos.component.html',
  styleUrls: ['./misdatos.component.scss'],
  standalone: true,
  imports: [
    IonCardTitle,
    IonCardContent,
    IonCardHeader,
    IonCard,
    IonItem,
    IonContent,
    IonInput,
    IonLabel,
    IonList,
    IonSelect,
    IonSelectOption,
    IonButton,
    FormsModule,
    NgFor,
    TranslateModule,
    DatePickerComponent
  ]
})
export class MisdatosComponent {
  usuario: Usuario = new Usuario();
  usuarios: Usuario[] = [];
  public listaNivelesEducacionales = NivelEducacional.getNivelesEducacionales();

  @ViewChild('itemCardTitulo', { read: ElementRef }) itemCardTitulo!: ElementRef;
  @ViewChild('itemCuenta', { read: ElementRef }) itemCuenta!: ElementRef;
  @ViewChild('itemCorreo', { read: ElementRef }) itemCorreo!: ElementRef;
  @ViewChild('itemNombre', { read: ElementRef }) itemNombre!: ElementRef;
  @ViewChild('itemApellido', { read: ElementRef }) itemApellido!: ElementRef;
  @ViewChild('itemNivelEducacional', { read: ElementRef }) itemNivelEducacional!: ElementRef;
  @ViewChild('itemFechaNacimiento', { read: ElementRef }) itemFechaNacimiento!: ElementRef;
  @ViewChild('itemPreguntaSecreta', { read: ElementRef }) itemPreguntaSecreta!: ElementRef;
  @ViewChild('itemRespuestaSecreta', { read: ElementRef }) itemRespuestaSecreta!: ElementRef;
  @ViewChild('itemContraseña', { read: ElementRef }) itemContraseña!: ElementRef;
  @ViewChild('itemRepetirContraseña', { read: ElementRef }) itemRepetirContraseña!: ElementRef;

  constructor(
    private animationController: AnimationController,
    private bd: DataBaseService,
    private auth: AuthService,
    private toastController: ToastController,
  ) {

    this.auth.leerUsuarioAutenticado().then((usuario) => {
      if (usuario) {
        this.usuario = usuario;
        console.log(this.usuario);
      }
    });
    
  }

  public actualizarNivelEducacional(event: any) {
    const nivelEducacional = NivelEducacional.buscarNivelEducacional(event.detail.value);
    if (nivelEducacional) {
      this.usuario.nivelEducacional = nivelEducacional;
    }
  }

  onFechaNacimientoChange(event: any) {
    this.usuario.fechaNacimiento = new Date(event.detail.value);
  }

  async actualizarUsuario() {
    try {
        console.log('Datos del usuario antes de actualizar:', this.usuario);

        // Asegúrate de que todos los campos requeridos estén llenos
        if (!this.usuario.cuenta || !this.usuario.correo) {
            await this.presentToast('Por favor, complete todos los campos requeridos');
            return;
        }

        await this.bd.actualizarUsuario(this.usuario);
        await this.presentToast('Usuario actualizado con éxito');
    } catch (error) {
        console.error('Error al actualizar el usuario:', error);
        await this.presentToast('Error al actualizar el usuario');
    }
}

  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000,
      position: 'top',
    });
    await toast.present();
  }

  public ionViewDidEnter() {
    const animations = [
      { element: this.itemCardTitulo.nativeElement, duration: 1500 },
      { element: this.itemCuenta.nativeElement, duration: 1600 },
      { element: this.itemNombre.nativeElement, duration: 1700 },
      { element: this.itemApellido.nativeElement, duration: 1800 },
      { element: this.itemCorreo.nativeElement, duration: 1900 },
      { element: this.itemPreguntaSecreta.nativeElement, duration: 2000 },
      { element: this.itemRespuestaSecreta.nativeElement, duration: 2100 },
      { element: this.itemNivelEducacional.nativeElement, duration: 2200 },
      { element: this.itemFechaNacimiento.nativeElement, duration: 2300 },
      { element: this.itemContraseña.nativeElement, duration: 2400 },
      { element: this.itemRepetirContraseña.nativeElement, duration: 2500 },
    ];

    animations.forEach(({ element, duration }) => {
      this.animacionItems(element, duration);
    });
  }

  public animacionItems(elementRef: any, duration: number) {
    const animation = this.animationController
      .create()
      .addElement(elementRef)
      .duration(duration)
      .iterations(1)
      .fromTo('transform', 'translateX(450px)', 'translateX(0px)')
      .fromTo('opacity', '0', '1');
    animation.play();
  }

  public animacionCardTitulo(elementRef: any, duration: number) {
    const animation = this.animationController
      .create()
      .addElement(elementRef)
      .duration(duration)
      .iterations(1)
      .fromTo('transform', 'translateY(-100px)', 'translateY(0px)');
    animation.play();
  }
}
