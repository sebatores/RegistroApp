import { CommonModule } from '@angular/common';
import { Component, ElementRef, EventEmitter, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { AnimationController } from '@ionic/angular';
import { IonCard, IonCardHeader, IonCardTitle, IonLabel, IonButton, IonIcon, IonContent, IonCardContent } from "@ionic/angular/standalone";
import { TranslateModule } from '@ngx-translate/core';
import { addIcons } from 'ionicons';
import { stopCircleOutline, videocamOutline } from 'ionicons/icons';
import jsQR, { QRCode } from 'jsqr';
import { Asistencia } from 'src/app/model/asistencia';
import { Usuario } from 'src/app/model/usuario';
import { AuthService } from 'src/app/services/auth.service';
import { LanguageComponent } from '../language/language.component';
import { DataBaseService } from 'src/app/services/data-base.service';
import { Capacitor } from '@capacitor/core';
import { ScannerService } from 'src/app/services/scanner.service';

@Component({
  selector: 'app-codigoqr',
  templateUrl: './codigoqr.component.html',
  styleUrls: ['./codigoqr.component.scss'],
  standalone: true,
  imports: [
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonLabel,
    IonButton,
    IonIcon,
    IonContent,
    IonCardContent,
    CommonModule, 
    FormsModule,
    TranslateModule,
    LanguageComponent
  ]
})
export class CodigoqrComponent implements OnDestroy {
  

  @ViewChild('titulo', {read: ElementRef}) itemTitulo!:ElementRef;
  @ViewChild('cardTitulo', {read: ElementRef}) itemCardTitulo!:ElementRef;
  
  @ViewChild('video') private video!: ElementRef;
  @ViewChild('canvas') private canvas!: ElementRef;
  @Output() scanned: EventEmitter<string> = new EventEmitter<string>();
  @Output() stopped: EventEmitter<void> = new EventEmitter<void>();

  usuario: Usuario = new Usuario();
  public escaneando = false;
  public datosQR: string = '';
  mediaStream: MediaStream | null = null; 


  constructor(
    private animationController: AnimationController,
    private authService: AuthService,
    private scanner: ScannerService
  ) 
  {

    this.authService.leerUsuarioAutenticado().then((usuario) => {
      if (usuario) {
        this.usuario = usuario;
      }
    });

    addIcons({ videocamOutline, stopCircleOutline });

  }

  async botonEscaneoQR() {

    if (Capacitor.getPlatform() === 'web')
      this.comenzarEscaneoQR();

    if (Capacitor.getPlatform() !== 'web')
        this.showDinoComponent(await this.scanner.scan());
  }

  showDinoComponent(qr: string) {
    if (Asistencia.esValidoQrCodeClase(qr)) {
      this.authService.qrCodeData.next(qr);
      this.authService.selectedComponent.next('miclase');
      return;
    }
    
    this.authService.selectedComponent.next('codigoqr');
  }

  async comenzarEscaneoQR() {
    this.mediaStream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: 'environment' }
    });

    this.video.nativeElement.srcObject = this.mediaStream;
    this.video.nativeElement.setAttribute('playsinline', 'true');
    this.video.nativeElement.play();
    this.escaneando = true;
    requestAnimationFrame(this.verificarVideo.bind(this));
  }

  async verificarVideo() {
    if (this.video.nativeElement.readyState === this.video.nativeElement.HAVE_ENOUGH_DATA) {
      if (this.obtenerDatosQR() || !this.escaneando) return;
      requestAnimationFrame(this.verificarVideo.bind(this));
    } else {
      requestAnimationFrame(this.verificarVideo.bind(this));
    }
  }

  //lectura QR
  obtenerDatosQR(): boolean {
    const w: number = this.video.nativeElement.videoWidth;
    const h: number = this.video.nativeElement.videoHeight;
    this.canvas.nativeElement.width = w;
    this.canvas.nativeElement.height = h;
    const context: CanvasRenderingContext2D = this.canvas.nativeElement.getContext('2d');
    context.drawImage(this.video.nativeElement, 0, 0, w, h);
    const img: ImageData = context.getImageData(0, 0, w, h);
    let qrCode: QRCode | null = jsQR(img.data, w, h, { inversionAttempts: 'dontInvert'});
    if (qrCode) {
      const data = qrCode.data;
      if (data !== '') {
        this.escaneando = false;
        this.authService.guardarUsuarioAutenticado(this.usuario!);
        console.log(this.usuario);
        this.authService.qrCodeData.next(qrCode.data);
        this.authService.selectedComponent.next('miclase');

        return true;
      }
    }
    return false;
  }

  detenerEscaneoQR(): void {
    this.stopCamera();
    this.stopped.emit();
    this.escaneando = false;
  }

  ngOnDestroy() {
    this.stopCamera();
  }

  stopCamera() {
    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach(track => track.stop()); // Detén todas las pistas de video
      this.mediaStream = null; // Limpia el flujo de medios
    }
  }


  // Animaciones
  
  public animateItem1(elementRef: any, duration: number) {
    const animation = this.animationController
    .create()
    .addElement (elementRef)
    .iterations(1)
    .duration(duration)
    .easing('ease-in')
    .fromTo('opacity', 0, 1);
    animation.play();
  }

  public ionViewDidEnter(){
    this.animateItem1(this.itemCardTitulo.nativeElement,3000);
  }



}
