import { QRCode } from 'jsqr';
import { CommonModule } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { IonContent, IonCard , IonCardHeader, IonCardTitle, IonCardContent, IonList, IonItem, IonInput, IonLabel } from "@ionic/angular/standalone";
import { TranslateModule } from '@ngx-translate/core';
import { Subscription } from 'rxjs';
import { Usuario } from 'src/app/model/usuario';
import { AuthService } from 'src/app/services/auth.service';
import { LanguageComponent } from '../language/language.component';

@Component({
  selector: 'app-miclase',
  templateUrl: './miclase.component.html',
  styleUrls: ['./miclase.component.scss'],
  standalone: true,
  imports: [IonLabel, IonContent, 
            IonCard, 
            IonCardHeader, 
            IonCardTitle, 
            IonCardContent, 
            IonList, 
            IonItem, 
            IonInput,
            CommonModule,
            TranslateModule,
            LanguageComponent]
})
export class MiclaseComponent implements OnDestroy {

  clase: any;
  private subscription: Subscription;

  constructor(
    private authService: AuthService
  ) {

    this.subscription = this.authService.qrCodeData.subscribe((qr) => {
      this.clase = qr? JSON.parse(qr): null;
    })
   }

   ngOnDestroy(): void {
    this.subscription.unsubscribe();
   }

}
