export class Publicacion {
  
  id = 0;
  autor = '';
  titulo = '';
  contenido = '';

  constructor() {
    
  }
}