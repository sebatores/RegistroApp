import { showAlert } from "../tools/message-functions";

export class Asistencia {

  public sede: string;
  public idAsignatura: string;
  public seccion: string;
  public nombreAsignatura: string;
  public nombreProfesor: string;
  public dia: string;
  public bloqueInicio: number;
  public bloqueTermino: number;
  public horaInicio: string;
  public horaTermino: string;
  

  constructor() {

    this.sede = '';
    this.idAsignatura = '';
    this.seccion = '';
    this.nombreAsignatura = '';
    this.nombreProfesor = '';
    this.dia = '';
    this.bloqueInicio = 0;
    this.bloqueTermino = 0;
    this.horaInicio = '';
    this.horaTermino = '';
    
  }

  public setAsistencia(

    sede: string,
    idAsignatura: string,
    seccion: string,
    nombreAsignatura: string,
    nombreProfesor: string,
    dia: string,
    bloqueInicio: number,
    bloqueTermino: number,
    horaInicio: string,
    horaTermino: string
  ): void {

    this.sede = sede;
    this.idAsignatura = idAsignatura;
    this.seccion = seccion;
    this.nombreAsignatura = nombreAsignatura;
    this.nombreProfesor = nombreProfesor;
    this.dia = dia;
    this.bloqueInicio = bloqueInicio;
    this.bloqueTermino = bloqueTermino;
    this.horaInicio = horaInicio;
    this.horaTermino = horaTermino;
    
  }

  static esValidoQrCodeClase(qr: string) {
    
    if (qr === '') return false;

    try {
      const json = JSON.parse(qr);

      if ( json.sede                  !== undefined
        && json.idAsignatura          !== undefined
        && json.seccion               !== undefined
        && json.nombreAsignatura      !== undefined
        && json.nombreProfesor        !== undefined
        && json.dia                   !== undefined
        && json.bloqueInicio          !== undefined
        && json.bloqueTermino         !== undefined
        && json.horaInicio            !== undefined
        && json.horaFin               !== undefined)
      {
        return true;
      }
    } catch(error) { }

    showAlert('El código QR escaneado no corresponde a una clase');
    return false;
  }

}
