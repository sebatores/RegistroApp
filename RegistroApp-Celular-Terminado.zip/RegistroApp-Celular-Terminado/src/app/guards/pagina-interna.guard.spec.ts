import { TestBed } from '@angular/core/testing';
import { CanActivateFn } from '@angular/router';

import { paginaInternaGuard } from './pagina-interna.guard';

describe('paginaInternaGuard', () => {
  const executeGuard: CanActivateFn = (...guardParameters) => 
      TestBed.runInInjectionContext(() => paginaInternaGuard(...guardParameters));

  beforeEach(() => {
    TestBed.configureTestingModule({});
  });

  it('should be created', () => {
    expect(executeGuard).toBeTruthy();
  });
});
