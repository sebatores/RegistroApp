import { CanActivateFn } from '@angular/router';

export const paginaInternaGuard: CanActivateFn = (route, state) => {
  return true;
};
